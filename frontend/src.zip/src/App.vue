<template>
  <div id="app">

<!--    <el-container id="app">-->
<!--      <el-header>-->

<!--      </el-header>-->
<!--      <el-main>-->
        <router-view />
<!--      </el-main>-->
<!--      <el-footer>-->
<!--&lt;!&ndash;        <i class="iconfont">&#xe614;</i>&ndash;&gt;-->
<!--      </el-footer>-->
<!--    </el-container>-->

  </div>
</template>

<style>

  /*#app {*/
  /*  font-family: Avenir, Helvetica, Arial, sans-serif;*/
  /*  -webkit-font-smoothing: antialiased;*/
  /*  -moz-osx-font-smoothing: grayscale;*/
  /*  text-align: center;*/
  /*  color: #2c3e50;*/
  /*}*/


  /*.el-header, .el-footer {*/
  /*  background-color: #B3C0D1;*/
  /*  color: #333;*/
  /*  text-align: center;*/
  /*  line-height: 60px;*/
  /*}*/
  /*.el-main {*/
  /*  background-color: #E9EEF3;*/
  /*  color: #333;*/
  /*  text-align: center;*/
  /*  line-height: 160px;*/
  /*}*/


</style>
