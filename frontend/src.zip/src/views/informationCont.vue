<template>
  <div class="mobileVerification">
    <mobileVerification></mobileVerification>
  </div>

</template>

<script>


import mobileVerification from "@/components/mobileVerification";

export default {
  name: 'InformationCont',
  components: {
    mobileVerification

  }
}
</script>

<style scoped>

</style>
