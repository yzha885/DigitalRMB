<template>
  <div class="information">
    <inputForm ></inputForm>
  </div>
</template>

<script>
// @ is an alias to /src
import inputForm from '@/components/personalInfo.vue'



export default {
  name: 'Home',
  components: {
    inputForm
  },
   methods:{


  }
}
</script>
